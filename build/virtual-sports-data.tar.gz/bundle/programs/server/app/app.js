var require = meteorInstall({"server":{"loadEvents.js":["babel-runtime/helpers/typeof",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// server/loadEvents.js                                                                                    //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
var _typeof2 = require('babel-runtime/helpers/typeof');                                                    //
                                                                                                           //
var _typeof3 = _interopRequireDefault(_typeof2);                                                           //
                                                                                                           //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }          //
                                                                                                           //
// loadEvents.js                                                                                           //
                                                                                                           //
if ((typeof virtualSportsAgent === 'undefined' ? 'undefined' : (0, _typeof3['default'])(virtualSportsAgent)) != 'object') virtualSportsAgent = {};
                                                                                                           //
virtualSportsAgent.loadEvents = function (callback) {                                                      // 5
                                                                                                           //
  console.log('Starting loadEvents function.');                                                            // 7
                                                                                                           //
  if (virtualSportsAgent.xsrftoken == null || virtualSportsAgent.cookie == null) {                         // 9
    console.log("xsrftoken/cookie not found.");                                                            // 10
    if (callback) callback(false);                                                                         // 11
    return;                                                                                                // 12
  }                                                                                                        //
                                                                                                           //
  var url = "https://www.betfair.com/sport/virtuals/football?modules=virtuals-marketview&openDate=1463706240000&action=virtualMarketViewNextEvents&lastId=1044&ts=1463705310646&alt=json&xsrftoken=" + virtualSportsAgent.xsrftoken;
                                                                                                           //
  //Fiber(function(){                                                                                      //
  try {                                                                                                    // 5
    var httpCall = Meteor.http.call("GET", url, {                                                          // 19
      headers: {                                                                                           // 20
        "X-Requested-With": "XMLHttpRequest",                                                              // 21
        "Accept": "*/*",                                                                                   // 22
        "Cookie": virtualSportsAgent.cookie                                                                // 23
      }                                                                                                    //
    });                                                                                                    //
                                                                                                           //
    if (httpCall.statusCode != 200) {                                                                      // 27
      console.log("httpCall.statusCode: " + httpCall.statusCode);                                          // 28
      if (callback) callback(false);                                                                       // 29
      return;                                                                                              // 30
    }                                                                                                      //
                                                                                                           //
    if (httpCall.content.indexOf('{"page":{"config"') > 100) {                                             // 33
      console.log("got a bad json result.");                                                               // 34
      if (callback) callback(false);                                                                       // 35
      return;                                                                                              // 36
    }                                                                                                      //
                                                                                                           //
    var data = JSON.parse(httpCall.content);                                                               // 39
                                                                                                           //
    var htmlStr = data.page.config.instructions[0].arguments.contentHtml;                                  // 41
                                                                                                           //
    //console.log(htmlStr);                                                                                //
                                                                                                           //
    var eventsId = htmlStr.match(/<div class="content .*? data-eventId="\d+/g);                            // 18
    var eventsName = htmlStr.match(/<div class="event-name">.*?(?=<\/div>)/g);                             // 46
    var eventsDescription = htmlStr.match(/<div class="event-description">.*?(?=<\/div>)/g);               // 47
                                                                                                           //
    //var marketMatchOdds = htmlStr.match(/<div class="market-selections table market-match-odds">.*?data-marketId=".*?"/g);
                                                                                                           //
    if (eventsId.length == 0 || eventsId.length != eventsName.length || eventsName.length != eventsDescription.length) {
      console.log("json parse error");                                                                     // 52
      return;                                                                                              // 53
    }                                                                                                      //
                                                                                                           //
    for (var i = 0; i < eventsId.length; i++) {                                                            // 56
      var id = eventsId[i].split('data-eventId="')[1];                                                     // 57
      var league = eventsDescription[i].split('>')[1];                                                     // 58
                                                                                                           //
      var name = eventsName[i].split('>')[1].split(' ');                                                   // 60
      var time = name[0];                                                                                  // 61
      name.splice(0, 1);                                                                                   // 62
      var match = name.join(' ').trim();                                                                   // 63
                                                                                                           //
      var event = {                                                                                        // 65
        id: id,                                                                                            // 66
        date: new Date(),                                                                                  // 67
        time: time,                                                                                        // 68
        match: match,                                                                                      // 69
        league: league                                                                                     // 70
      };                                                                                                   //
                                                                                                           //
      //console.log(event);                                                                                //
      Events.upsert({ id: id }, { $set: event });                                                          // 56
    }                                                                                                      //
                                                                                                           //
    console.log('Finished loadEvents function.');                                                          // 77
    if (callback) callback(true);                                                                          // 78
  } catch (e) {                                                                                            //
    // Got a network error, time-out or HTTP error in the 400 or 500 range.                                //
    console.log("error", e);                                                                               // 82
    if (callback) callback(false);                                                                         // 83
  }                                                                                                        //
  //}).run();                                                                                              //
};                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"login.js":["babel-runtime/helpers/typeof",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// server/login.js                                                                                         //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
var _typeof2 = require('babel-runtime/helpers/typeof');                                                    //
                                                                                                           //
var _typeof3 = _interopRequireDefault(_typeof2);                                                           //
                                                                                                           //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }          //
                                                                                                           //
// login.js                                                                                                //
                                                                                                           //
if ((typeof virtualSportsAgent === 'undefined' ? 'undefined' : (0, _typeof3['default'])(virtualSportsAgent)) != 'object') virtualSportsAgent = {};
                                                                                                           //
virtualSportsAgent.login = function (callback) {                                                           // 5
                                                                                                           //
	console.log('Inside login function !!!!!!!!!');                                                           // 7
                                                                                                           //
	virtualSportsAgent.url = "https://www.betfair.com/sport/virtuals/football";                               // 9
	virtualSportsAgent.testindex = 0;                                                                         // 10
	virtualSportsAgent.loadInProgress = false;                                                                // 11
                                                                                                           //
	Phantom.create(["--web-security=no", "--ignore-ssl-errors=yes", "--load-images=no"]).then(function (ph) {
                                                                                                           //
		ph.createPage().then(function (page) {                                                                   // 15
                                                                                                           //
			page.onConsoleMessage = function (msg) {                                                                // 17
				console.log(msg);                                                                                      // 18
			};                                                                                                      //
                                                                                                           //
			page.onLoadStarted = function () {                                                                      // 21
				virtualSportsAgent.loadInProgress = true;                                                              // 22
				console.log("load started");                                                                           // 23
			};                                                                                                      //
                                                                                                           //
			page.onLoadFinished = function () {                                                                     // 26
				virtualSportsAgent.loadInProgress = false;                                                             // 27
				console.log("load finished");                                                                          // 28
			};                                                                                                      //
                                                                                                           //
			virtualSportsAgent.steps = [                                                                            // 31
                                                                                                           //
			////////// Step 1 - Open Virtual Sports Page //////////                                                 //
                                                                                                           //
			function () {                                                                                           // 35
				console.log("opening page: " + virtualSportsAgent.url);                                                // 36
				page.open(virtualSportsAgent.url);                                                                     // 37
			},                                                                                                      //
                                                                                                           //
			////////// Step 2 - Login //////////                                                                    //
                                                                                                           //
			function () {                                                                                           // 42
				page.evaluate(function () {                                                                            // 43
					console.log("filling login details...");                                                              // 44
					document.getElementById("ssc-liu").value = "guli@tocarta.es";                                         // 45
					document.getElementById("ssc-lipw").value = "guliguli1";                                              // 46
					var theForm = document.getElementsByClassName("ssc-lif")[0];                                          // 47
					theForm.submit();                                                                                     // 48
					console.log("form submitted.");                                                                       // 49
				});                                                                                                    //
			},                                                                                                      //
                                                                                                           //
			////////// Step 3 - Save Cookie //////////                                                              //
                                                                                                           //
			function () {                                                                                           // 55
				page.evaluate(function () {                                                                            // 56
					var res = "";                                                                                         // 57
					if (document.cookie != null) res = document.cookie;                                                   // 58
					return res;                                                                                           // 59
				}).then(function (cookie) {                                                                            //
					//console.log("cookie",cookie);                                                                       //
					if (cookie == null || cookie == "") {                                                                 // 62
						console.log("not logged!");                                                                          // 63
						virtualSportsAgent.logged = false;                                                                   // 64
						return false;                                                                                        // 65
					}                                                                                                     //
					virtualSportsAgent.cookie = cookie;                                                                   // 67
					var xsrftokenStr = cookie.match(/xsrftoken=[a-z0-9-]+/g)[0];                                          // 68
					if (xsrftokenStr != null && xsrftokenStr != "") {                                                     // 69
						virtualSportsAgent.xsrftoken = xsrftokenStr.split("xsrftoken=")[1];                                  // 70
						console.log("logged successful!");                                                                   // 71
						virtualSportsAgent.logged = true;                                                                    // 72
						return true;                                                                                         // 73
					} else {                                                                                              //
						console.log("not logged!");                                                                          // 76
						virtualSportsAgent.logged = false;                                                                   // 77
						return false;                                                                                        // 78
					}                                                                                                     //
				});                                                                                                    //
			}];                                                                                                     //
                                                                                                           //
			virtualSportsAgent.interval = setInterval(function () {                                                 // 86
				if (!virtualSportsAgent.loadInProgress && typeof virtualSportsAgent.steps[virtualSportsAgent.testindex] == "function") {
					console.log("step " + (virtualSportsAgent.testindex + 1));                                            // 88
					virtualSportsAgent.steps[virtualSportsAgent.testindex]();                                             // 89
					virtualSportsAgent.testindex++;                                                                       // 90
				}                                                                                                      //
				if (typeof virtualSportsAgent.steps[virtualSportsAgent.testindex] != "function") {                     // 92
					clearInterval(virtualSportsAgent.interval);                                                           // 93
					console.log("test complete!");                                                                        // 94
					ph.exit();                                                                                            // 95
					setTimeout(function () {                                                                              // 96
						if (callback) callback(virtualSportsAgent.logged);                                                   // 97
					}, 2000);                                                                                             //
				}                                                                                                      //
			}, 2000);                                                                                               //
		});                                                                                                      //
	});                                                                                                       //
};                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"saveMarketPrices.js":["babel-runtime/helpers/typeof",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// server/saveMarketPrices.js                                                                              //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
var _typeof2 = require('babel-runtime/helpers/typeof');                                                    //
                                                                                                           //
var _typeof3 = _interopRequireDefault(_typeof2);                                                           //
                                                                                                           //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }          //
                                                                                                           //
// saveMarketPrices.js                                                                                     //
                                                                                                           //
if ((typeof virtualSportsAgent === 'undefined' ? 'undefined' : (0, _typeof3['default'])(virtualSportsAgent)) != 'object') virtualSportsAgent = {};
                                                                                                           //
virtualSportsAgent.saveMarketPrices = function () {                                                        // 5
                                                                                                           //
  console.log('Inside saveMarketPrices function !!!!!!!!!');                                               // 7
                                                                                                           //
  var url = "https://www.betfair.com/www/sports/fixedodds/readonly/v1/getMarketPrices?_ak=FIhovAzZxtrvphhu&priceHistory=0&xsrftoken=" + virtualSportsAgent.xsrftoken;
                                                                                                           //
  //Fiber(function(){                                                                                      //
  try {                                                                                                    // 5
    var httpCall = HTTP.call("POST", url, {                                                                // 13
      headers: {                                                                                           // 14
        "X-Requested-With": "XMLHttpRequest",                                                              // 15
        "Accept": "application/json",                                                                      // 16
        "Content-Type": "application/json",                                                                // 17
        "Cookie": virtualSportsAgent.cookie                                                                // 18
      },                                                                                                   //
      data: {                                                                                              // 20
        "alt": "json",                                                                                     // 21
        "currencyCode": "GBP",                                                                             // 22
        "locale": "en_GB",                                                                                 // 23
        "marketIds": ["924.52836406", "924.52836411"]                                                      // 24
      }                                                                                                    //
    });                                                                                                    //
    console.log("httpCall.statusCode: ", httpCall.statusCode);                                             // 27
    console.log("httpCall.content", httpCall.content);                                                     // 28
    if (httpCall.statusCode != 200) return;                                                                // 29
  } catch (e) {                                                                                            //
    // Got a network error, time-out or HTTP error in the 400 or 500 range.                                //
    console.log("error", e);                                                                               // 33
  }                                                                                                        //
  //}).run();                                                                                              //
};                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"saveResults.js":["babel-runtime/helpers/typeof",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// server/saveResults.js                                                                                   //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
var _typeof2 = require('babel-runtime/helpers/typeof');                                                    //
                                                                                                           //
var _typeof3 = _interopRequireDefault(_typeof2);                                                           //
                                                                                                           //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }          //
                                                                                                           //
// saveResults.js                                                                                          //
                                                                                                           //
if ((typeof virtualSportsAgent === 'undefined' ? 'undefined' : (0, _typeof3['default'])(virtualSportsAgent)) != 'object') virtualSportsAgent = {};
                                                                                                           //
virtualSportsAgent.saveResults = function (callback) {                                                     // 5
                                                                                                           //
  console.log('Starting saveResults function.');                                                           // 7
                                                                                                           //
  if (virtualSportsAgent.xsrftoken == null || virtualSportsAgent.cookie == null) {                         // 9
    console.log("xsrftoken/cookie not found.");                                                            // 10
    if (callback) callback(false);                                                                         // 11
    return;                                                                                                // 12
  }                                                                                                        //
                                                                                                           //
  var url = "https://www.betfair.com/sport/virtuals/football?modules=virtuals-latest-results&sport=SOCCER&action=update&lastId=1044&ts=1463963943720&alt=json&xsrftoken=" + virtualSportsAgent.xsrftoken;
                                                                                                           //
  try {                                                                                                    // 17
    var httpCall = HTTP.call("GET", url, {                                                                 // 18
      headers: {                                                                                           // 19
        "X-Requested-With": "XMLHttpRequest",                                                              // 20
        "Accept": "*/*",                                                                                   // 21
        "Cookie": virtualSportsAgent.cookie                                                                // 22
      }                                                                                                    //
    });                                                                                                    //
                                                                                                           //
    if (httpCall.statusCode != 200) {                                                                      // 26
      console.log("httpCall.statusCode: " + httpCall.statusCode);                                          // 27
      if (callback) callback(false);                                                                       // 28
      return;                                                                                              // 29
    }                                                                                                      //
                                                                                                           //
    if (httpCall.content.indexOf('{"page":{"config"') > 100) {                                             // 32
      console.log("got a bad json result.");                                                               // 33
      if (callback) callback(false);                                                                       // 34
      return;                                                                                              // 35
    }                                                                                                      //
                                                                                                           //
    var data = JSON.parse(httpCall.content);                                                               // 38
                                                                                                           //
    for (var i = 0; i < data.page.config.instructions.length; i++) {                                       // 40
      var htmlStr = data.page.config.instructions[i].arguments.html;                                       // 41
      if (!htmlStr) continue;                                                                              // 42
                                                                                                           //
      var teams = htmlStr.match(/<div class="individual-team">.*?(?=<\/div>)/g);                           // 44
      var scores = htmlStr.match(/<div class="score">.*?(?=<\/div>)/g);                                    // 45
                                                                                                           //
      var homeTeam = teams[0].split('>')[1].trim();                                                        // 47
      var homeGoals = parseInt(scores[0].split('>')[1].trim());                                            // 48
      var awayTeam = teams[1].split('>')[1].trim();                                                        // 49
      var awayGoals = parseInt(scores[1].split('>')[1].trim());                                            // 50
      var match = homeTeam + ' v ' + awayTeam;                                                             // 51
                                                                                                           //
      var event = {                                                                                        // 53
        match: match,                                                                                      // 54
        homeTeam: homeTeam,                                                                                // 55
        homeGoals: homeGoals,                                                                              // 56
        awayTeam: awayTeam,                                                                                // 57
        awayGoals: awayGoals,                                                                              // 58
        totalGoals: homeGoals + awayGoals,                                                                 // 59
        homeWin: homeGoals > awayGoals,                                                                    // 60
        awayWin: homeGoals < awayGoals,                                                                    // 61
        draw: homeGoals == awayGoals                                                                       // 62
      };                                                                                                   //
                                                                                                           //
      //console.log(event);                                                                                //
                                                                                                           //
      var obj = Events.findOne({ match: match }, { sort: { date: -1 } });                                  // 40
      if (obj != null) {                                                                                   // 68
        Events.update({ _id: obj._id }, { $set: event });                                                  // 69
        console.log(_.extend(obj, event));                                                                 // 70
      }                                                                                                    //
    }                                                                                                      //
                                                                                                           //
    console.log('Finished saveResults function.');                                                         // 75
    if (callback) callback(true);                                                                          // 76
  } catch (e) {                                                                                            //
    // Got a network error, time-out or HTTP error in the 400 or 500 range.                                //
    console.log("error", e);                                                                               // 80
    if (callback) callback(false);                                                                         // 81
  }                                                                                                        //
};                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"main.js":["babel-runtime/helpers/typeof","meteor/meteor",function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// server/main.js                                                                                          //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
var _typeof2 = require('babel-runtime/helpers/typeof');                                                    //
                                                                                                           //
var _typeof3 = _interopRequireDefault(_typeof2);                                                           //
                                                                                                           //
var _meteor = require('meteor/meteor');                                                                    // 1
                                                                                                           //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }          //
                                                                                                           //
_meteor.Meteor.startup(function () {                                                                       // 3
                                                                                                           //
  // Load the libraries                                                                                    //
                                                                                                           //
  Fiber = _meteor.Meteor.npmRequire('fibers');                                                             // 7
  Phantom = _meteor.Meteor.npmRequire('phantom');                                                          // 8
  // phantomjs = Meteor.npmRequire('phantomjs');                                                           //
  // spawn = Meteor.npmRequire('child_process').spawn;                                                     //
                                                                                                           //
  // Initialize the Collections                                                                            //
                                                                                                           //
  Events = new Mongo.Collection("events");                                                                 // 3
});                                                                                                        //
                                                                                                           //
if ((typeof virtualSportsAgent === 'undefined' ? 'undefined' : (0, _typeof3['default'])(virtualSportsAgent)) != 'object') virtualSportsAgent = {};
                                                                                                           //
/////// APIs ///////                                                                                       //
                                                                                                           //
_meteor.Meteor.methods({                                                                                   // 22
                                                                                                           //
  startVirtualSportsAgent: function () {                                                                   // 24
    function startVirtualSportsAgent() {                                                                   // 24
                                                                                                           //
      var pollingInterval = 60 * 1000; // every minute                                                     // 26
      var attempts = 3;                                                                                    // 24
                                                                                                           //
      try {                                                                                                // 29
                                                                                                           //
        var tryLogin = function () {                                                                       // 31
          function tryLogin(intents, cbk, _i) {                                                            // 31
            virtualSportsAgent.login(function (logged) {                                                   // 32
              if (_i == null) _i = 1;                                                                      // 33
              if (logged) return cbk(true);                                                                // 34
              if (_i >= intents) return cbk(false);                                                        // 35
              _i++;                                                                                        // 36
              tryLogin(intents, cbk, _i);                                                                  // 37
            });                                                                                            //
          }                                                                                                //
                                                                                                           //
          return tryLogin;                                                                                 //
        }();                                                                                               //
                                                                                                           //
        var start = function () {                                                                          // 41
          function start() {                                                                               // 41
            tryLogin(attempts, function (logged) {                                                         // 42
              if (!logged) {                                                                               // 43
                console.log("Failed to login 3 times.");                                                   // 44
                return false;                                                                              // 45
              }                                                                                            //
              var saveData = function () {                                                                 // 47
                function saveData() {                                                                      // 47
                  Fiber(function () {                                                                      // 48
                    virtualSportsAgent.loadEvents(function (ok) {                                          // 49
                      if (!ok) return start();                                                             // 50
                      virtualSportsAgent.saveResults(function (ok) {                                       // 51
                        if (!ok) return start();                                                           // 52
                        setTimeout(saveData, pollingInterval);                                             // 53
                      });                                                                                  //
                    });                                                                                    //
                  }).run();                                                                                //
                }                                                                                          //
                                                                                                           //
                return saveData;                                                                           //
              }();                                                                                         //
              saveData();                                                                                  // 58
            });                                                                                            //
          }                                                                                                //
                                                                                                           //
          return start;                                                                                    //
        }();                                                                                               //
                                                                                                           //
        start();                                                                                           // 62
      } catch (e) {                                                                                        //
        console.log("error: ", e);                                                                         // 65
      }                                                                                                    //
                                                                                                           //
      return { res: "success" };                                                                           // 68
    }                                                                                                      //
                                                                                                           //
    return startVirtualSportsAgent;                                                                        //
  }(),                                                                                                     //
                                                                                                           //
  login: function () {                                                                                     // 71
    function login(callback) {                                                                             // 71
      try {                                                                                                // 72
        virtualSportsAgent.login(callback);                                                                // 73
      } catch (e) {                                                                                        //
        console.log("error: ", e);                                                                         // 75
      }                                                                                                    //
      return { res: "success" };                                                                           // 77
    }                                                                                                      //
                                                                                                           //
    return login;                                                                                          //
  }(),                                                                                                     //
                                                                                                           //
  loadEvents: function () {                                                                                // 80
    function loadEvents() {                                                                                // 80
      try {                                                                                                // 81
        virtualSportsAgent.loadEvents();                                                                   // 82
      } catch (e) {                                                                                        //
        console.log("error: ", e);                                                                         // 84
      }                                                                                                    //
      return { res: "success" };                                                                           // 86
    }                                                                                                      //
                                                                                                           //
    return loadEvents;                                                                                     //
  }(),                                                                                                     //
                                                                                                           //
  saveResults: function () {                                                                               // 89
    function saveResults() {                                                                               // 89
      try {                                                                                                // 90
        virtualSportsAgent.saveResults();                                                                  // 91
      } catch (e) {                                                                                        //
        console.log("error: ", e);                                                                         // 93
      }                                                                                                    //
      return { res: "success" };                                                                           // 95
    }                                                                                                      //
                                                                                                           //
    return saveResults;                                                                                    //
  }(),                                                                                                     //
                                                                                                           //
  saveMarketPrices: function () {                                                                          // 98
    function saveMarketPrices() {                                                                          // 98
      try {                                                                                                // 99
        virtualSportsAgent.saveMarketPrices();                                                             // 100
      } catch (e) {                                                                                        //
        console.log("error: ", e);                                                                         // 102
      }                                                                                                    //
      return { res: "success" };                                                                           // 104
    }                                                                                                      //
                                                                                                           //
    return saveMarketPrices;                                                                               //
  }()                                                                                                      //
                                                                                                           //
});                                                                                                        //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"main.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// main.js                                                                                                 //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
// main.js                                                                                                 //
                                                                                                           //
Router.route('/', function () {                                                                            // 3
  this.render('main');                                                                                     // 4
});                                                                                                        //
                                                                                                           //
// Router.route('/start',function(){                                                                       //
// 	Meteor.call("login");                                                                                  //
// 	this.render('start');                                                                                  //
// });                                                                                                     //
                                                                                                           //
Router.route('/start');                                                                                    // 14
Router.route('/stop');                                                                                     // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{"extensions":[".js",".json"]});
require("./server/loadEvents.js");
require("./server/login.js");
require("./server/saveMarketPrices.js");
require("./server/saveResults.js");
require("./server/main.js");
require("./main.js");
//# sourceMappingURL=app.js.map
